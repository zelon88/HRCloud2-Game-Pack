<!DOCTYPE HTML>
<?php
$noStyles = 1;
/*//
HRCLOUD2-PLUGIN-START
App Name: ClumsyBird
App Website: https://github.com/ellisonleao/clumsy-bird
App Version: v1.1 (3-25-2019 00:00)
App License: GPLv3
App Author: ellisonaleo
App Genre: Games
App Description: A flappy bird clone!
App Integration: 0 (True)
HRCLOUD2-PLUGIN-END
//*/
?>
<html lang="en">
    <head>
        <title>Clumsy Bird</title>
        <link rel="apple-touch-icon-precomposed" href="data/img/touch-icon-iphone.png"/>
        <link rel="apple-touch-icon-precomposed" sizes="120x120" href="data/img/touch-icon-iphone-retina.png"/>
        <link rel="shortcut icon" href="data/img/favicon.ico">
        <link rel="stylesheet" type="text/css" media="screen" href="index.css">
        <meta id="viewport" name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
        <meta name="apple-mobile-web-app-capable" content="yes">
        <meta name="apple-mobile-web-app-status-bar-style" content="black">
        <meta name="apple-mobile-web-app-title" content="Clumsy Bird">
        <meta charset="UTF-8" />
        <meta name="description" content="Clumsy Bird - A Flappy Bird clone using MelonJS"/>
        <meta name="keywords" content="flappybird, flappy, bird, game, html5, melonjs,clone"/>
        <meta name="robots" content="index, follow">
        <meta name="google-site-verification" content="RDZI9SqVaffd48uHfZMv67-YdvviOMe2HuULEYqVgd4" />
        <meta property="og:image" content="http://ellisonleao.github.io/clumsy-bird/data/img/bg.png" />
        <meta property="og:title" content="Clumsy Bird - A Flappy Bird clone using MelonJS"/>
        <meta property="og:url" content="http://ellisonleao.github.io/clumsy-bird/"/>
        <meta property="og:site_name" content="Clumsy Bird - MelonJS"/>

        <!-- Twitter Card -->
        <meta name="twitter:hashtag" content="clumsybird" />
        <meta name="twitter:card" content="summary" />
        <meta name="twitter:site" content="@ellisonleao" />
        <meta name="twitter:creator" content="@ellisonleao" />
        <meta name="twitter:title" content="Clumsy Bird" />
        <meta name="twitter:description" content="A Flappy Bird melonJS clone" />

        <!-- Humans -->
        <link rel="author" href="humans.txt" />
    </head>

    <body>
        <!-- Canvas placeholder -->
        <div id="screen"></div>

        <!-- melonJS Library -->
        <script type="text/javascript" src="js/melonJS-min.js" ></script>
        <script type="text/javascript" src="build/clumsy-min.js" ></script>
        <script type="text/javascript">
            window.onReady(function onReady() {
                game.onload();
            });
        </script>

    </body>
</html>
