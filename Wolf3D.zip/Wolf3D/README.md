Wolfenstein 3D HTML5
======

Made for Bethesda/Zenimax's celebration of the 20th anniversary of Wolfenstein 3D.

Demo: http://git.nihilogic.dk/wolf3d/
