3d.city
=======

3d city builder [LAUNCH](http://lo-th.github.io/3d.city/index.html)<br>

The goal is create 3d city builder to test performance for webgl games<br>
With minimum size impact and maximum speed.<br>
(world.sea:161 ko, view.min.js:71 ko, city.3d.min.js:130 ko)<br>
Webgl 3d side use [Three.js](https://github.com/mrdoob/three.js), 3d model use [Sea3d](https://github.com/sunag/sea3d) format.<br>

This game use simulation source micropolisJS by Graememcc<br>
[https://github.com/graememcc/micropolisJS](https://github.com/graememcc/micropolisJS). Is a port of Micropolis to JS/HTML5.<br>
Licensed under the GPLv3 with some additional terms please be mindful of these.<br>

I have remove all thirdparty library, compact the code and push game simulation in a web worker.

Work in progress

[building destroy](http://lo-th.github.io/3d.city/test_destruct.html)<br>
[helicopter test](http://lo-th.github.io/3d.city/test_helicopter.html)<br>
[low version](http://lo-th.github.io/3d.city/index_low.html)<br>

<a target='_blank' href='http://lo-th.github.io/3d.city/index.html'><img src="http://lo-th.github.io/3d.city/img/preview01.jpg"/></a><br>
<a target='_blank' href='http://lo-th.github.io/3d.city/index.html'><img src="http://lo-th.github.io/3d.city/img/preview02.jpg"/></a><br>
<a target='_blank' href='http://lo-th.github.io/3d.city/index.html'><img src="http://lo-th.github.io/3d.city/img/preview03.jpg"/></a><br>